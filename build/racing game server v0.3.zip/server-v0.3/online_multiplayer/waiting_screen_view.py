import pygame
import global_variables as gv


