def option_menu(window):
    pass

